import React from 'react';
import './style.scss';

const _Sample = (props) => {
	return (
		<div>
			{props.chilren}
		</div>
	)
}
export default _Sample;
