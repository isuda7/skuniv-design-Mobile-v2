export { default as DefaultPage } from './DefaultPage';
export { default as FormPage } from './FormPage';
export { default as ButtonPage } from './ButtonPage';
export { default as IconPage } from './IconPage';
export { default as LabelPage } from './LabelPage';
export { default as DividerPage } from './DividerPage';
export { default as TabPage } from './TabPage';
export { default as AccordionPage } from './AccordionPage';
export { default as DragDropPage } from './DragDropPage';
export { default as ModalPage } from './ModalPage';
export { default as PopupPage } from './PopupPage';
export { default as EtcPageGroup } from './EtcPageGroup';
export { default as GuidePage } from './GuidePage'; //복사용
