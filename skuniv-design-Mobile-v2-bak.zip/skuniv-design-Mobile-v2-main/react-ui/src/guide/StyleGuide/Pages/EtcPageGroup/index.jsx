import React from 'react'
// Page
import {
    PopupPage
} from '..'

const EtcPageGroup = () => {
    return (
        <>
            {/* Popups */}
            <PopupPage />
        </>
    )
}

export default EtcPageGroup