import React from 'react';

const ContentHead = () => {
    return (
        <div className='content_head'>
            <h2>Heading2</h2>
        </div>
    )
}
export default ContentHead
