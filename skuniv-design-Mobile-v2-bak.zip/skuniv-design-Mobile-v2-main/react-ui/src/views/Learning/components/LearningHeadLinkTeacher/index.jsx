import React from 'react';
import './style.scss';

const LearningHeadLinkTeacher = (props) => {
	return (
		<div className='learning_head_teacher'>
			{props.children}
		</div>

	)
}
export default LearningHeadLinkTeacher
