import React from "react";

const VideoPlayer = () => {
	return (
		<div>

		</div>
	)
}
export default VideoPlayer;
