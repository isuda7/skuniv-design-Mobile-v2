import React from "react";
import './style.scss';

const CubeReferences = (props) => {
	return (
		<div className='cube_references'>
			{props.children}
		</div>
	)
}
export default CubeReferences;