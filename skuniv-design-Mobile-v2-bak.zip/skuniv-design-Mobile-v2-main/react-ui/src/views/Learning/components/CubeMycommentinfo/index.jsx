import React from "react";
import './style.scss';

const CubeMycommentinfo = (props) => {
	return (
		<div className='info_list'>
			{props.children}
		</div>
	)
}
export default CubeMycommentinfo;