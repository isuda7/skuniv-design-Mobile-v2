import React from 'react';
import {Section01} from '../../components';

const ContentBody = () => {
    return (
        <div className='content_body'>
            <Section01 />
        </div>
    )
}
export default ContentBody
