import React from 'react';
import './style.scss';

const Section01 = () => {
    return (
        <div></div>
    )
}

export default Section01